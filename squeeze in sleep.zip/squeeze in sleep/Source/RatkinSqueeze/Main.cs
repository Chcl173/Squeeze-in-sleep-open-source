﻿using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;
using UnityEngine;
using System;
using System.Reflection;
using Verse.AI;
using Verse.AI.Group;
using System.Reflection.Emit;
using System.Linq;

#nullable disable
namespace RatkinSqueeze;

public class RatkinSqueezeMod : Mod
{
    public const string HarmonyId = "shuzu.ratkinsqueeze";

    public RatkinSqueezeMod(ModContentPack content)
      : base(content)
    {
        Harmony harmony = new Harmony("shuzu.ratkinsqueeze");
        harmony.PatchAll(Assembly.GetExecutingAssembly());
        Patch_CurrentBed.Apply(harmony);
        Log.Message("[挤一挤] 已加载：Harmony 补丁全部就绪（种族=Ratkin）。");
    }
}
public static class SqueezeUtil
{
    public const string RatkinRaceDefName = "Ratkin";

    public static bool IsSqueezePawn(Pawn pawn)
    {
        return pawn != null && pawn.def != null && pawn.RaceProps != null && pawn.RaceProps.Humanlike && pawn.def.defName == "Ratkin";
    }

    public static bool IsSqueezeBed(Building_Bed bed)
    {
        return bed != null && bed.def != null && bed.def.building != null && bed.def.building.bed_humanlike && !bed.Medical && !bed.ForHumanBabies && bed.def.size.x >= 1 && bed.def.size.z >= 2;
    }

    public static int BaseSlots(Building_Bed bed)
    {
        return bed == null || bed.def == null ? 1 : bed.def.size.x;
    }

    public static int EffSlotsFor(Pawn pawn, Building_Bed bed)
    {
        int num = SqueezeUtil.BaseSlots(bed);
        return SqueezeUtil.IsSqueezePawn(pawn) && SqueezeUtil.IsSqueezeBed(bed) ? num * 2 : num;
    }

    public static int LayoutSlots(Building_Bed bed)
    {
        int num = SqueezeUtil.BaseSlots(bed);
        return SqueezeUtil.IsSqueezeBed(bed) ? num * 2 : num;
    }

    public static int ReserveSlotsFor(Building_Bed bed)
    {
        return SqueezeUtil.IsSqueezeBed(bed) ? SqueezeUtil.BaseSlots(bed) * 2 : SqueezeUtil.BaseSlots(bed);
    }

    public static bool HasFreeGuestSlot(Pawn pawn, Building_Bed bed)
    {
        if (!IsSqueezePawn(pawn) || !IsSqueezeBed(bed))
            return false;

        int capacity = BaseSlots(bed) * 2;
        List<Pawn> owners = bed.OwnersForReading;
        int currentWeight = 0;
        if (owners != null)
        {
            foreach (Pawn p in owners)
            {
                if (p == null) continue;
                currentWeight += IsSqueezePawn(p) ? 1 : 2;
            }
        }
        int newWeight = IsSqueezePawn(pawn) ? 1 : 2;
        return (currentWeight + newWeight) <= capacity;
    }

    public static int CountSqueezeSleepers(Building_Bed bed)
    {
        if (bed == null || !bed.Spawned)
            return 0;
        int num1 = SqueezeUtil.LayoutSlots(bed);
        int num2 = 0;
        for (int slotIndex = 0; slotIndex < num1; ++slotIndex)
        {
            Pawn curOccupant = bed.GetCurOccupant(slotIndex);
            if (curOccupant != null && SqueezeUtil.IsSqueezePawn(curOccupant))
                ++num2;
        }
        return num2;
    }

    public static CellRect BedRect(Building_Bed bed) => bed.OccupiedRect();

    public static Vector3 BedRectCenterWorld(CellRect rect)
    {
        return new Vector3((float)((double)(rect.minX + rect.maxX) / 2.0 + 0.5), 0.0f, (float)((double)(rect.minZ + rect.maxZ) / 2.0 + 0.5));
    }

    public static bool HasOtherSharer(Pawn p, Building_Bed bed)
    {
        List<Pawn> ownersForReading = bed.OwnersForReading;
        if (ownersForReading != null)
        {
            for (int index = 0; index < ownersForReading.Count; ++index)
            {
                if (ownersForReading[index] != null && ownersForReading[index] != p)
                    return true;
            }
        }
        int num = SqueezeUtil.LayoutSlots(bed);
        for (int slotIndex = 0; slotIndex < num; ++slotIndex)
        {
            Pawn curOccupant = bed.GetCurOccupant(slotIndex);
            if (curOccupant != null && curOccupant != p)
                return true;
        }
        return false;
    }

    public static bool IdeoAllowsSharing(Pawn p, Building_Bed bed)
    {
        List<Pawn> ownersForReading = bed.OwnersForReading;
        if (ownersForReading != null)
        {
            for (int index = 0; index < ownersForReading.Count; ++index)
            {
                if (ownersForReading[index] != null && ownersForReading[index] != p && !BedUtility.WillingToShareBed(p, ownersForReading[index]))
                    return false;
            }
        }
        int num = SqueezeUtil.LayoutSlots(bed);
        for (int slotIndex = 0; slotIndex < num; ++slotIndex)
        {
            Pawn curOccupant = bed.GetCurOccupant(slotIndex);
            if (curOccupant != null && curOccupant != p && !BedUtility.WillingToShareBed(p, curOccupant))
                return false;
        }
        return true;
    }

    //260906新增
    public static float GetHeadDistance(Building_Bed bed, int slotIndex)
    {
        if (bed == null) return 999f;

        IntVec3 slotPos = bed.GetSleepingSlotPos(slotIndex);
        IntVec3 bedCenter = bed.Position;
        IntVec3 headDirection;

        switch (bed.Rotation.AsInt)
        {
            case 0: // North: 床头在 Z 负方向（Z 小）
                headDirection = new IntVec3(0, 0, -1);
                break;
            case 1: // East: 床头在 X 正方向（X 大）
                headDirection = new IntVec3(1, 0, 0);
                break;
            case 2: // South: 床头在 Z 正方向（Z 大）
                headDirection = new IntVec3(0, 0, 1);
                break;
            case 3: // West: 床头在 X 负方向（X 小）
                headDirection = new IntVec3(-1, 0, 0);
                break;
            default:
                return 999f;
        }

        // 计算槽位在床头方向上的投影值（越大越靠近床头）
        Vector3 dirVec = headDirection.ToVector3();
        Vector3 slotVec = slotPos.ToVector3() - bedCenter.ToVector3();
        return Vector3.Dot(slotVec, dirVec);
    }

    //260907新增
    public static int GetSlotColumn(Building_Bed bed, int slotIndex)
    {
        int baseSlots = BaseSlots(bed);
        return (baseSlots <= 1) ? 0 : (slotIndex % 2);
    }

    public static bool IsHeadSlot(Building_Bed bed, int slotIndex)
    {
        return slotIndex < BaseSlots(bed);
    }

}

[HarmonyPatch(typeof(Building_Bed), "GetCurOccupantAt")]
public static class Patch_BedGetCurOccupantAt
{
    public static bool Prefix(Building_Bed __instance, IntVec3 pos, ref Pawn __result)
    {
        int num = SqueezeUtil.LayoutSlots(__instance);
        for (int index = 0; index < num; ++index)
        {
            if (__instance.GetSleepingSlotPos(index) == pos)
            {
                __result = __instance.GetCurOccupant(index);
                return false;
            }
        }
        __result = (Pawn)null;
        return false;
    }
}

[HarmonyPatch(typeof(Building_Bed), "GetCurOccupantSlotIndex")]
public static class Patch_BedGetCurOccupantSlotIndex
{
    public static bool Prefix(Building_Bed __instance, Pawn curOccupant, ref int __result)
    {
        int num = SqueezeUtil.EffSlotsFor(curOccupant, __instance);
        for (int slotIndex = 0; slotIndex < num; ++slotIndex)
        {
            if (__instance.GetCurOccupant(slotIndex) == curOccupant)
            {
                __result = slotIndex;
                return false;
            }
        }
        Log.Warning($"[挤一挤] 找不到 {(curOccupant != null ? curOccupant.ToString() : "null")} 所在的床位格。");
        __result = 0;
        return false;
    }
}

//260907修改
[HarmonyPatch(typeof(Building_Bed), "GetFootSlotPos")]
public static class Patch_BedGetFootSlotPos
{
    public static bool Prefix(Building_Bed __instance, int index, ref IntVec3 __result)
    {
        int baseSlots = SqueezeUtil.BaseSlots(__instance);
        if (index < 0 || index >= baseSlots * 2 || !SqueezeUtil.IsSqueezeBed(__instance))
            return true;

        int col = (baseSlots == 1) ? 0 : index % 2;
        __result = BedUtility.GetFeetSlotPos(col, __instance.Position, __instance.Rotation, __instance.def.size);
        return false;
    }
}

[HarmonyPatch(typeof(Building_Bed), "GetSleepingSlotPos")]
public static class Patch_BedGetSleepingSlotPos
{
    public static bool Prefix(Building_Bed __instance, int index, ref IntVec3 __result)
    {
        int baseSlots = SqueezeUtil.BaseSlots(__instance);
        if (index < 0 || index >= baseSlots * 2 || !SqueezeUtil.IsSqueezeBed(__instance))
            return true;

        // 单人床只有一列，床尾槽位列号仍为 0
        int col = (baseSlots == 1) ? 0 : index % 2;
        bool isHead = index < baseSlots;  // 单人床：0=床头，1=床尾；双人床：0,1=床头，2,3=床尾

        if (isHead)
            __result = BedUtility.GetSleepingSlotPos(col, __instance.Position, __instance.Rotation, __instance.def.size);
        else
            __result = BedUtility.GetFeetSlotPos(col, __instance.Position, __instance.Rotation, __instance.def.size);

        return false;
    }
}

//260907修改
[HarmonyPatch(typeof(Building_Bed), "DrawGUIOverlay")]
public static class Patch_BedOwnerNamesLayout
{
    public static bool Prefix(Building_Bed __instance)
    {
        if (__instance.Medical || Find.CameraDriver.CurrentZoom != CameraZoomRange.Closest || !__instance.CompAssignableToPawn.PlayerCanSeeAssignments)
            return true;

        List<Pawn> ownersForReading = __instance.OwnersForReading;
        if (ownersForReading == null || ownersForReading.Count <= 1 || !SqueezeUtil.IsSqueezeBed(__instance))
            return true;

        int num1 = SqueezeUtil.BaseSlots(__instance);
        CellRect rect = SqueezeUtil.BedRect(__instance);
        IntVec3 sleepingSlotPos = __instance.GetSleepingSlotPos(0);
        IntVec3 footSlotPos = __instance.GetFootSlotPos(0);
        Vector3 vector3_1 = new Vector3((float)(sleepingSlotPos.x - footSlotPos.x), 0.0f, (float)(sleepingSlotPos.z - footSlotPos.z));
        float num2 = (float)Math.Sqrt((double)vector3_1.x * (double)vector3_1.x + (double)vector3_1.z * (double)vector3_1.z);
        if ((double)num2 < 0.0099999997764825821)
            return true;

        vector3_1.x /= num2;
        vector3_1.z /= num2;
        Vector3 vector3_2 = new Vector3(-vector3_1.z, 0.0f, vector3_1.x);
        float num3 = (double)Math.Abs(vector3_1.x) > 0.5 ? (float)(rect.maxX - rect.minX + 1) : (float)(rect.maxZ - rect.minZ + 1);
        Vector3 vector3_3 = SqueezeUtil.BedRectCenterWorld(rect);
        vector3_3.x -= vector3_1.x * (float)(((double)num3 - 1.0) / 2.0 * 0.5);
        vector3_3.z -= vector3_1.z * (float)(((double)num3 - 1.0) / 2.0 * 0.5);
        Color defaultThingLabelColor = GenMapUI.DefaultThingLabelColor;

        // 收集需要显示名称的 pawn
        List<Pawn> pawnList = new List<Pawn>();
        for (int index = 0; index < ownersForReading.Count; ++index)
        {
            Pawn pawn = ownersForReading[index];
            if (pawn != null && (!pawn.Spawned || !pawn.InBed() || pawn.CurrentBed() != __instance || !(pawn.Position == __instance.GetSleepingSlotPos(index))) && (!pawn.RaceProps.Animal || Prefs.AnimalNameMode.ShouldDisplayAnimalName(pawn)))
                pawnList.Add(pawn);
        }
        if (pawnList.Count == 0)
            return false;

        // 按列分组：左列（0,2）和右列（1,3），先绘制左列
        List<Pawn> leftColPawns = new List<Pawn>();
        List<Pawn> rightColPawns = new List<Pawn>();
        for (int i = 0; i < pawnList.Count; i++)
        {
            Pawn pawn = pawnList[i];
            int slotIndex = ownersForReading.IndexOf(pawn);
            int col = SqueezeUtil.GetSlotColumn(__instance, slotIndex);
            if (col == 0) leftColPawns.Add(pawn);
            else rightColPawns.Add(pawn);
        }

        List<Pawn> orderedPawns = new List<Pawn>();
        orderedPawns.AddRange(leftColPawns);
        orderedPawns.AddRange(rightColPawns);

        int num4 = num1 > 1 ? 2 : 1;

        Vector2 uiPosition1 = new Vector3((float)rect.minX, 0.0f, (float)rect.minZ).MapToUIPosition();
        Vector2 uiPosition2 = new Vector3((float)(rect.maxX + 1), 0.0f, (float)rect.minZ).MapToUIPosition();
        Vector2 uiPosition3 = new Vector3((float)rect.minX, 0.0f, (float)(rect.maxZ + 1)).MapToUIPosition();
        Vector2 uiPosition4 = new Vector3((float)(rect.maxX + 1), 0.0f, (float)(rect.maxZ + 1)).MapToUIPosition();

        float num6 = Mathf.Min(Mathf.Min(uiPosition1.x, uiPosition2.x), Mathf.Min(uiPosition3.x, uiPosition4.x));
        float num7 = Mathf.Max(Mathf.Max(uiPosition1.x, uiPosition2.x), Mathf.Max(uiPosition3.x, uiPosition4.x));
        float num8 = Mathf.Min(Mathf.Min(uiPosition1.y, uiPosition2.y), Mathf.Min(uiPosition3.y, uiPosition4.y));
        float num9 = Mathf.Max(Mathf.Max(uiPosition1.y, uiPosition2.y), Mathf.Max(uiPosition3.y, uiPosition4.y));

        for (int index = 0; index < orderedPawns.Count; ++index)
        {
            Pawn pawn = orderedPawns[index];
            int slotIndex = ownersForReading.IndexOf(pawn);

            int num10 = slotIndex % num4;
            float num12 = num4 > 1 ? (num10 == 0 ? -0.42f : 0.42f) : 0.0f;

            // 以床矩形中心为基准
            Vector3 v = vector3_3;
            // 横向偏移（宽度方向）
            v.x += vector3_2.x * num12;
            v.z += vector3_2.z * num12;

            // 纵向偏移：床头排（slotIndex 0、1）保持在中心，床尾排（slotIndex 2、3）向床尾方向移半格
            if (slotIndex >= SqueezeUtil.BaseSlots(__instance))
            {
                v.x -= vector3_1.x * 0.5f;
                v.z -= vector3_1.z * 0.5f;
            }

            Vector2 uiPosition5 = v.MapToUIPosition();
            uiPosition5.x = Mathf.Clamp(uiPosition5.x, num6 + 10f, num7 - 10f);
            uiPosition5.y = Mathf.Clamp(uiPosition5.y, num8 + 8f, num9 - 8f);

            GenMapUI.DrawThingLabel(uiPosition5, pawn.LabelShort, defaultThingLabelColor);
        }

        return false;
    }
}

[HarmonyPatch(typeof(RestUtility), "CanUseBedNow")]
public static class Patch_CanUseBedNow
{
    public static bool Prefix(
      Thing bedThing,
      Pawn sleeper,
      bool checkSocialProperness,
      bool allowMedBedEvenIfSetToNoCare,
      GuestStatus? guestStatusOverride,
      ref bool __result)
    {
        if (!(bedThing is Building_Bed buildingBed) || !SqueezeUtil.IsSqueezePawn(sleeper) || !SqueezeUtil.IsSqueezeBed(buildingBed))
            return true;
        bool flag1 = false;
        if (!buildingBed.Spawned || buildingBed.Map != sleeper.MapHeld || buildingBed.IsBurning())
            flag1 = true;
        else if (sleeper.HarmedByVacuum && (double)buildingBed.Position.GetVacuum(buildingBed.Map) >= 0.5)
            flag1 = true;
        else if (!RestUtility.CanUseBedEver(sleeper, buildingBed.def))
            flag1 = true;
        else if (buildingBed.CompAssignableToPawn.IdeoligionForbids(sleeper))
            flag1 = true;
        if (!flag1)
        {
            int? assignedSleepingSlot;
            bool flag2 = buildingBed.IsOwner(sleeper, out assignedSleepingSlot);
            int? sleepingSlot;
            bool flag3 = sleeper.CurrentBed(out sleepingSlot) == buildingBed;
            GuestStatus? nullable1 = guestStatusOverride;
            GuestStatus? nullable2 = nullable1.HasValue ? new GuestStatus?(nullable1.GetValueOrDefault()) : sleeper.GuestStatus;
            GuestStatus? nullable3 = nullable2;
            bool forPrisoner = nullable3.GetValueOrDefault() == GuestStatus.Prisoner && nullable3.HasValue;
            GuestStatus? nullable4 = nullable2;
            bool flag4 = nullable4.GetValueOrDefault() == GuestStatus.Slave && nullable4.HasValue;
            if (!flag2 && !flag3 && !SqueezeUtil.HasFreeGuestSlot(sleeper, buildingBed))
                flag1 = true;
            else if (!flag2 && !flag3 && SqueezeUtil.HasOtherSharer(sleeper, buildingBed) && !SqueezeUtil.IdeoAllowsSharing(sleeper, buildingBed))
                flag1 = true;
            else if (checkSocialProperness && !buildingBed.IsSociallyProper(sleeper, forPrisoner))
                flag1 = true;
            else if (buildingBed.ForPrisoners != forPrisoner || buildingBed.ForSlaves != flag4)
                flag1 = true;
            else if (buildingBed.ForPrisoners && !buildingBed.Position.IsInPrisonCell(buildingBed.Map))
                flag1 = true;
            else if (buildingBed.Medical && !allowMedBedEvenIfSetToNoCare && !HealthAIUtility.ShouldEverReceiveMedicalCareFromPlayer(sleeper))
                flag1 = true;
            else if (buildingBed.Medical && !HealthAIUtility.ShouldSeekMedicalRest(sleeper))
            {
                flag1 = true;
            }
            else
            {
                if (!buildingBed.Medical && flag2 && flag3)
                {
                    int? nullable5 = sleepingSlot;
                    int? nullable6 = assignedSleepingSlot;
                    if ((nullable5.GetValueOrDefault() != nullable6.GetValueOrDefault() ? 1 : (nullable5.HasValue != nullable6.HasValue ? 1 : 0)) != 0)
                    {
                        flag1 = true;
                        goto label_31;
                    }
                }
                if (sleeper.IsColonist && !forPrisoner)
                {
                    Verse.AI.Job curJob = sleeper.CurJob;
                    if ((curJob == null || !curJob.ignoreForbidden) && !sleeper.Downed && buildingBed.IsForbidden(sleeper))
                        flag1 = true;
                }
            }
        }
    label_31:
        __result = !flag1;
        return false;
    }
}

// 260906修改（动态踢人：新来鼠族踢人类，新来人类踢鼠族）
[HarmonyPatch(typeof(Pawn_Ownership), "ClaimBedIfNonMedical")]
public static class Patch_ClaimBedIfNonMedical
{
    private static System.Reflection.MethodInfo ownedBedSetter;

    private static void SetOwnedBed(Pawn_Ownership ownership, Building_Bed bed)
    {
        if (ownedBedSetter == null)
            ownedBedSetter = AccessTools.PropertySetter(typeof(Pawn_Ownership), "OwnedBed");
        ownedBedSetter.Invoke(ownership, new object[] { bed });
    }

    public static bool Prefix(Pawn_Ownership __instance, Building_Bed newBed, ref bool __result)
    {
        Pawn pawn = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();

        if (pawn == null || newBed == null || newBed.Medical)
            return true;

        // ---- 死亡rest委托给原版 ----
        if (ModsConfig.BiotechActive && newBed.def == ThingDefOf.DeathrestCasket)
        {
            __result = __instance.ClaimDeathrestCasket(newBed);
            return false;
        }

        if (!SqueezeUtil.IsSqueezeBed(newBed))
            return true;

        if (newBed.IsOwner(pawn))
        {
            __result = false;
            return false;
        }

        if (SqueezeUtil.HasOtherSharer(pawn, newBed) && !SqueezeUtil.IdeoAllowsSharing(pawn, newBed))
        {
            __result = false;
            return false;
        }

        // ---- 计算权重 ----
        List<Pawn> owners = newBed.OwnersForReading;
        int capacity = SqueezeUtil.BaseSlots(newBed) * 2;
        int currentWeight = 0;
        if (owners != null)
        {
            foreach (Pawn p in owners)
            {
                if (p == null) continue;
                currentWeight += SqueezeUtil.IsSqueezePawn(p) ? 1 : 2;
            }
        }

        int newWeight = SqueezeUtil.IsSqueezePawn(pawn) ? 1 : 2;
        int totalWeight = currentWeight + newWeight;

        // ---- 空间足够 ----
        if (totalWeight <= capacity)
        {
            __instance.UnclaimBed();
            newBed.CompAssignableToPawn.ForceAddPawn(pawn);
            SetOwnedBed(__instance, newBed);
            __result = true;
            return false;
        }

        // ---- 需要踢人（动态优先级） ----
        int toKickWeight = totalWeight - capacity;
        List<Pawn> toKick = new List<Pawn>();
        int kickedWeight = 0;

        if (owners != null)
        {
            bool newIsRatkin = SqueezeUtil.IsSqueezePawn(pawn);

            if (newIsRatkin)
            {
                // 新来鼠族 → 优先踢非鼠族（权重2）
                for (int i = owners.Count - 1; i >= 0 && kickedWeight < toKickWeight; i--)
                {
                    Pawn p = owners[i];
                    if (p == null) continue;
                    if (!SqueezeUtil.IsSqueezePawn(p))
                    {
                        toKick.Add(p);
                        kickedWeight += 2;
                    }
                }
                // 还不够再踢鼠族
                for (int i = owners.Count - 1; i >= 0 && kickedWeight < toKickWeight; i--)
                {
                    Pawn p = owners[i];
                    if (p == null) continue;
                    if (SqueezeUtil.IsSqueezePawn(p))
                    {
                        toKick.Add(p);
                        kickedWeight += 1;
                    }
                }
            }
            else
            {
                // 新来非鼠族 → 优先踢鼠族（权重1）
                for (int i = owners.Count - 1; i >= 0 && kickedWeight < toKickWeight; i--)
                {
                    Pawn p = owners[i];
                    if (p == null) continue;
                    if (SqueezeUtil.IsSqueezePawn(p))
                    {
                        toKick.Add(p);
                        kickedWeight += 1;
                    }
                }
                // 还不够再踢非鼠族
                for (int i = owners.Count - 1; i >= 0 && kickedWeight < toKickWeight; i--)
                {
                    Pawn p = owners[i];
                    if (p == null) continue;
                    if (!SqueezeUtil.IsSqueezePawn(p))
                    {
                        toKick.Add(p);
                        kickedWeight += 2;
                    }
                }
            }
        }

        if (toKick.Count == 0)
        {
            __result = false;
            return false;
        }

        // ---- 执行踢人 ----
        CompAssignableToPawn comp = newBed.CompAssignableToPawn;
        foreach (Pawn p in toKick)
        {
            comp.ForceRemovePawn(p);
            p.ownership.UnclaimBed();

            if (p.Spawned && p.Map != null)
            {
                p.Map.reservationManager.ReleaseAllClaimedBy(p);
            }

            if (p.Spawned && p.InBed())
            {
                RestUtility.KickOutOfBed(p, newBed);
            }
        }

        // ---- 加入新指派者 ----
        __instance.UnclaimBed();
        newBed.CompAssignableToPawn.ForceAddPawn(pawn);
        SetOwnedBed(__instance, newBed);
        __result = true;
        return false;
    }
}
//260906新增
[HarmonyPatch(typeof(RestUtility), "CanUseBedNow")]
public static class Patch_CanUseBedNow_Prefix
{
    public static bool Prefix(
        Thing bedThing,
        Pawn sleeper,
        bool checkSocialProperness,
        bool allowMedBedEvenIfSetToNoCare,
        GuestStatus? guestStatusOverride,
        ref bool __result)
    {
        // 只处理挤压床 + 鼠族
        if (!(bedThing is Building_Bed bed) || !SqueezeUtil.IsSqueezeBed(bed) || !SqueezeUtil.IsSqueezePawn(sleeper))
            return true; // 走原版

        // ---- 以下完全复制原版逻辑，但修改床位容量检查 ----
        if (!bed.Spawned || bed.Map != sleeper.MapHeld || bed.IsBurning())
            return false;

        if (sleeper.HarmedByVacuum && (double)bed.Position.GetVacuum(bed.Map) >= 0.5)
            return false;

        if (!RestUtility.CanUseBedEver(sleeper, bed.def))
            return false;

        if (bed.CompAssignableToPawn.IdeoligionForbids(sleeper))
            return false;

        // ---- 使用权重计算判断床位是否可用 ----
        int? assignedSlot;
        bool isOwner = bed.IsOwner(sleeper, out assignedSlot);
        int? currentSlot;
        bool isCurrent = sleeper.CurrentBed(out currentSlot) == bed;

        // 计算当前床位权重是否已满
        if (!isOwner && !isCurrent)
        {
            // 使用你的权重方法判断是否还有空位
            if (!SqueezeUtil.HasFreeGuestSlot(sleeper, bed))
                return false;
        }

        GuestStatus? guest = guestStatusOverride ?? sleeper.GuestStatus;
        bool forPrisoner = guest == GuestStatus.Prisoner;
        bool forSlave = guest == GuestStatus.Slave;

        if (checkSocialProperness && !bed.IsSociallyProper(sleeper, forPrisoner))
            return false;

        if (bed.ForPrisoners != forPrisoner || bed.ForSlaves != forSlave)
            return false;

        if (bed.ForPrisoners && !bed.Position.IsInPrisonCell(bed.Map))
            return false;

        if (bed.Medical)
        {
            if (!allowMedBedEvenIfSetToNoCare && !HealthAIUtility.ShouldEverReceiveMedicalCareFromPlayer(sleeper))
                return false;
            if (!HealthAIUtility.ShouldSeekMedicalRest(sleeper))
                return false;
        }

        if (sleeper.IsColonist && !forPrisoner)
        {
            Job curJob = sleeper.CurJob;
            if ((curJob == null || !curJob.ignoreForbidden) && !sleeper.Downed && bed.IsForbidden(sleeper))
                return false;
        }

        __result = true;
        return false;
    }
}

public static class Patch_CurrentBed
{
    public static void Apply(Harmony harmony)
    {
        MethodBase original = (MethodBase)AccessTools.Method(typeof(RestUtility), "CurrentBed", new System.Type[2]
        {
      typeof (Pawn),
      typeof (int?).MakeByRefType()
        });
        if (original != (MethodBase)null)
            harmony.Patch(original, new HarmonyMethod(typeof(Patch_CurrentBed), "Prefix"));
        else
            Log.Warning("[挤一挤] 未找到 RestUtility.CurrentBed(Pawn, out int?) 方法，相关补丁未生效。");
    }

    public static bool Prefix(Pawn p, out int? sleepingSlot, ref Building_Bed __result)
    {
        if (!SqueezeUtil.IsSqueezePawn(p))
        {
            sleepingSlot = new int?();
            return true;
        }
        sleepingSlot = new int?();
        if (p == null || !p.Spawned || p.CurJob == null || !p.GetPosture().InBed())
        {
            __result = (Building_Bed)null;
            return false;
        }

        // ---------- 修正开始 ----------
        Building_Bed bed = null;  // 明确声明类型
        List<Thing> thingList = p.Position.GetThingList(p.Map);
        for (int index = 0; index < thingList.Count; index++)
        {
            if (thingList[index] is Building_Bed foundBed)
            {
                bed = foundBed;
                break;
            }
        }
        // ---------- 修正结束 ----------

        if (bed == null)
        {
            __result = (Building_Bed)null;
            return false;
        }

        int num = SqueezeUtil.EffSlotsFor(p, bed);
        for (int slotIndex = 0; slotIndex < num; ++slotIndex)
        {
            if (bed.GetCurOccupant(slotIndex) == p)
            {
                sleepingSlot = new int?(slotIndex);
                __result = bed;
                return false;
            }
        }
        __result = (Building_Bed)null;
        return false;
    }
}

//260906修改
[HarmonyPatch(typeof(RestUtility), "GetBedSleepingSlotPosFor")]
public static class Patch_GetBedSleepingSlotPosFor
{
    public static bool Prefix(Pawn pawn, Building_Bed bed, ref IntVec3 __result)
    {
        if (!SqueezeUtil.IsSqueezePawn(pawn) || !SqueezeUtil.IsSqueezeBed(bed))
            return true;

        int? assignedSleepingSlot;
        if (bed.IsOwner(pawn, out assignedSleepingSlot))
        {
            __result = bed.GetSleepingSlotPos(assignedSleepingSlot.Value);
            return false;
        }

        int num = SqueezeUtil.EffSlotsFor(pawn, bed);
        List<Pawn> ownersForReading = bed.OwnersForReading;
        int count = ownersForReading == null ? 0 : ownersForReading.Count;

        // 按床头距离排序
        List<int> slotOrder = new List<int>();
        for (int i = 0; i < num; i++) slotOrder.Add(i);
        slotOrder.Sort((a, b) =>
            SqueezeUtil.GetHeadDistance(bed, b).CompareTo(SqueezeUtil.GetHeadDistance(bed, a))
        ); // 降序：离床头近的排前面

        foreach (int index in slotOrder)
        {
            Pawn curOccupant = bed.GetCurOccupant(index);
            if ((index >= count || ownersForReading[index] == null) && curOccupant == pawn)
            {
                __result = bed.GetSleepingSlotPos(index);
                return false;
            }
        }

        foreach (int index in slotOrder)
        {
            Pawn curOccupant = bed.GetCurOccupant(index);
            if ((index >= count || ownersForReading[index] == null) && curOccupant == null)
            {
                __result = bed.GetSleepingSlotPos(index);
                return false;
            }
        }

        Log.Error($"[挤一挤] 找不到适合 {(pawn != null ? pawn.ToString() : "null")} 的空床位格。");
        __result = bed.GetSleepingSlotPos(0);
        return false;
    }
}

[HarmonyPatch(typeof(PawnRenderer), "GetBodyPos")]
public static class Patch_GetBodyPosTail
{
    public static void Postfix(PawnRenderer __instance, ref Vector3 __result)
    {
        Pawn pawn = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();
        if (pawn == null || !pawn.Spawned || !SqueezeUtil.IsSqueezePawn(pawn) || !pawn.GetPosture().InBed())
            return;

        int? sleepingSlot;
        Building_Bed bed = pawn.CurrentBed(out sleepingSlot);
        if (bed == null || !SqueezeUtil.IsSqueezeBed(bed) || !sleepingSlot.HasValue || bed.def.building.bed_showSleeperBody)
            return;

        // ---- 统计床上总人数 ----
        int totalSlots = SqueezeUtil.LayoutSlots(bed);
        int totalSleepers = 0;
        bool hasNonRatkin = false;
        int nonRatkinBaseSlot = -1; // 非鼠族所在列（新映射：0=左列，1=右列）
        for (int i = 0; i < totalSlots; i++)
        {
            Pawn occupant = bed.GetCurOccupant(i);
            if (occupant != null)
            {
                totalSleepers++;
                if (!SqueezeUtil.IsSqueezePawn(occupant))
                {
                    hasNonRatkin = true;
                    nonRatkinBaseSlot = i % 2; // 改用 %2
                }
            }
        }

        // ---- 获取当前槽位信息 ----
        int slotIndex = sleepingSlot.Value;
        int col = SqueezeUtil.GetSlotColumn(bed, slotIndex);
        bool isHead = SqueezeUtil.IsHeadSlot(bed, slotIndex);

        // 同列床头位置
        IntVec3 headSlotPos = bed.GetSleepingSlotPos(col);
        // 同列床尾位置（col + 2 得到同列床尾的槽位索引）
        IntVec3 currentFootPos = bed.GetFootSlotPos(slotIndex); // 直接使用修正后的 GetFootSlotPos，支持单人床
        IntVec3 currentPos = bed.GetSleepingSlotPos(slotIndex);

        // ---- 动态坐标判断 ----
        Rot4 rot = bed.Rotation;
        if (rot == Rot4.North)
            isHead = currentPos.z > currentFootPos.z;
        else if (rot == Rot4.South)
            isHead = currentPos.z < currentFootPos.z;
        else if (rot == Rot4.East)
            isHead = currentPos.x < currentFootPos.x;
        else
            isHead = currentPos.x > currentFootPos.x;

        // ---- 情况1：总人数 <= 2 且双人床 ----
        if (totalSleepers <= 2 && SqueezeUtil.BaseSlots(bed) >= 2)
        {
            if (!isHead)
            {
                bool hasHeadOccupant = false;
                int headSlotIndex = col; // 改：床头槽位就是 col（0 或 1）
                Pawn headOccupant = bed.GetCurOccupant(headSlotIndex);
                if (headOccupant != null && headOccupant != pawn)
                    hasHeadOccupant = true;

                if (hasHeadOccupant)
                {
                    int otherBaseSlot = (col == 0) ? 1 : 0; // 改
                    if (otherBaseSlot < SqueezeUtil.BaseSlots(bed))
                    {
                        IntVec3 targetPos = bed.GetSleepingSlotPos(otherBaseSlot); // 改：目标列床头的槽位就是 otherBaseSlot
                        __result.x += targetPos.x + 0.5f - (currentPos.x + 0.5f);
                        __result.z += targetPos.z + 0.5f - (currentPos.z + 0.5f);
                    }
                }
                else
                {
                    __result.x += headSlotPos.x + 0.5f - (currentPos.x + 0.5f);
                    __result.z += headSlotPos.z + 0.5f - (currentPos.z + 0.5f);
                }
            }
            return;
        }

        // ---- 情况2：总人数 == 3 且存在非鼠族 ----
        if (totalSleepers == 3 && hasNonRatkin && SqueezeUtil.IsSqueezePawn(pawn))
        {
            int targetBaseSlot = (nonRatkinBaseSlot == 0) ? 1 : 0;

            if (col != targetBaseSlot) // 改
            {
                IntVec3 targetPos = bed.GetSleepingSlotPos(targetBaseSlot); // 改：目标列床头的槽位就是 targetBaseSlot
                __result.x += targetPos.x + 0.5f - (currentPos.x + 0.5f);
                __result.z += targetPos.z + 0.5f - (currentPos.z + 0.5f);
                currentPos = targetPos;
                // isHead 保持 true（因为移动到床头位置）
            }

            // ---- 横向错开：两个鼠族在同一列左右分开 ----
            // 计算横向方向（床的宽度方向）
            Vector3 lateralDir;
            if (rot == Rot4.North || rot == Rot4.South)
                lateralDir = new Vector3(1f, 0f, 0f); // 东西方向
            else
                lateralDir = new Vector3(0f, 0f, 1f); // 南北方向

            // 根据槽位奇偶性决定偏移方向（0=床头向左，1=床尾向右）
            float lateralOffset = 0.2f; // 偏移量
            if (sleepingSlot.Value % 2 == 0) // 床头槽位
            {
                __result.x += lateralDir.x * lateralOffset;
                __result.z += lateralDir.z * lateralOffset;
            }
            else // 床尾槽位
            {
                __result.x -= lateralDir.x * lateralOffset;
                __result.z -= lateralDir.z * lateralOffset;
            }
            return;
        }

        // ---- 情况3：其他情况（单人床 或 双人床人数 > 3）走原版逻辑 ----
        if (SqueezeUtil.CountSqueezeSleepers(bed) <= 1)
        {
            if (sleepingSlot.Value % 2 != 1)
                return;
            int num = sleepingSlot.Value / 2;
            IntVec3 sleepingSlotPos1 = bed.GetSleepingSlotPos(num * 2);
            IntVec3 sleepingSlotPos2 = bed.GetSleepingSlotPos(sleepingSlot.Value);
            __result.x += (float)((double)sleepingSlotPos1.x + 0.5 - ((double)sleepingSlotPos2.x + 0.5));
            __result.z += (float)((double)sleepingSlotPos1.z + 0.5 - ((double)sleepingSlotPos2.z + 0.5));
        }
        else
        {
            // ---- 所有鼠族都定位到床头侧，但在宽度方向上分散 ----
            CellRect rect = SqueezeUtil.BedRect(bed);
            Vector3 center = SqueezeUtil.BedRectCenterWorld(rect);

            // 根据床旋转，确定长度方向和宽度方向
            Rot4 bedRot = bed.Rotation;  // 使用 bedRot 避免与外部 rot 冲突
            Vector3 lengthDir;
            Vector3 widthDir;
            if (bedRot == Rot4.North)
            {
                lengthDir = new Vector3(0f, 0f, -1f);
                widthDir = new Vector3(1f, 0f, 0f);
            }
            else if (bedRot == Rot4.South)
            {
                lengthDir = new Vector3(0f, 0f, 1f);
                widthDir = new Vector3(1f, 0f, 0f);
            }
            else if (bedRot == Rot4.East)
            {
                lengthDir = new Vector3(-1f, 0f, 0f); // 床头在 X 负方向
                widthDir = new Vector3(0f, 0f, 1f);
            }
            else // West
            {
                lengthDir = new Vector3(1f, 0f, 0f);  // 床头在 X 正方向
                widthDir = new Vector3(0f, 0f, 1f);
            }

            // 床的物理宽度（格子数）
            float bedWidth = bed.def.size.x;

            // 所有鼠族都在床头侧：长度方向偏移 +半格
            float lengthOffset = (bed.def.size.z - 1) * 0.5f;

            // 宽度方向根据槽位分散：4个槽位（0,1,2,3）均匀分布在床宽上
            // 槽位0: -0.75, 槽位1: -0.25, 槽位2: +0.25, 槽位3: +0.75（相对于床宽中心）
            float widthPos;
            if (bedWidth <= 1f)
            {
                // 单人床：两个槽位在宽度方向微偏移（±0.3格）
                widthPos = (slotIndex % 2 == 0) ? -0.3f : 0.3f;
            }
            else
            {
                // 双人床或更宽：原公式
                widthPos = (slotIndex / 3f - 0.5f) * (bedWidth - 1) * 1.5f;
            }
            // slotIndex=0 → -0.5*(bedWidth-1)  左边缘
            // slotIndex=1 → -0.166*(bedWidth-1)
            // slotIndex=2 → +0.166*(bedWidth-1)
            // slotIndex=3 → +0.5*(bedWidth-1)   右边缘

            Vector3 targetPos = center + lengthDir * lengthOffset + widthDir * widthPos;

            // 当前格子中心
            Vector3 currentCenter = new Vector3(currentPos.x + 0.5f, 0f, currentPos.z + 0.5f);

            // 应用偏移
            __result.x += targetPos.x - currentCenter.x;
            __result.z += targetPos.z - currentCenter.z;
        }
    }
}

[HarmonyPatch(typeof(RestUtility), "IsValidBedFor")]
public static class Patch_IsValidBedFor
{
    public static bool Prefix(
      Thing bedThing,
      Pawn sleeper,
      Pawn traveler,
      bool checkSocialProperness,
      bool allowMedBedEvenIfSetToNoCare,
      bool ignoreOtherReservations,
      GuestStatus? guestStatus,
      ref bool __result)
    {
        if (!(bedThing is Building_Bed buildingBed) || !SqueezeUtil.IsSqueezeBed(buildingBed))
            return true;
        bool flag1 = false;
        if (!RestUtility.CanUseBedNow(bedThing, sleeper, checkSocialProperness, allowMedBedEvenIfSetToNoCare, guestStatus))
            flag1 = true;
        if (!flag1 && !traveler.CanReach((LocalTargetInfo)(Thing)buildingBed, PathEndMode.OnCell, Danger.Some))
            flag1 = true;
        int maxPawns = SqueezeUtil.ReserveSlotsFor(buildingBed);
        if (!flag1 && !sleeper.HasReserved((LocalTargetInfo)(Thing)buildingBed) && !traveler.CanReserve((LocalTargetInfo)(Thing)buildingBed, maxPawns, 0, ignoreOtherReservations: ignoreOtherReservations))
            flag1 = true;
        if (!flag1 && traveler.HasReserved<JobDriver_TakeToBed>((LocalTargetInfo)(Thing)buildingBed, new LocalTargetInfo?((LocalTargetInfo)(Thing)sleeper)))
            flag1 = true;
        if (!flag1 && buildingBed.IsForbidden(traveler))
            flag1 = true;
        GuestStatus? nullable1 = guestStatus;
        bool flag2 = nullable1.GetValueOrDefault() == GuestStatus.Prisoner && nullable1.HasValue;
        GuestStatus? nullable2 = guestStatus;
        bool flag3 = nullable2.GetValueOrDefault() == GuestStatus.Slave && nullable2.HasValue;
        if (!flag1 && !flag2 && !flag3 && buildingBed.Faction != traveler.Faction && (traveler.HostFaction == null || buildingBed.Faction != traveler.HostFaction))
            flag1 = true;
        if (!flag1 && ModsConfig.AnomalyActive && sleeper.IsMutant && sleeper.needs.rest == null && sleeper.mutant.Def.entitledToMedicalCare && !buildingBed.Medical)
            flag1 = true;
        __result = !flag1;
        return false;
    }
}

[HarmonyPatch(typeof(JobDriver_LayDown), "TryMakePreToilReservations")]
public static class Patch_LayDownReserve
{
    public static bool Prefix(JobDriver_LayDown __instance, bool errorOnFailed, ref bool __result)
    {
        Pawn pawn = __instance.pawn;
        Building_Bed bed = __instance.Bed;
        Verse.AI.Job job = __instance.job;
        if (bed != null)
        {
            if (!SqueezeUtil.IsSqueezeBed(bed))
                return true;
            int maxPawns = SqueezeUtil.ReserveSlotsFor(bed);
            __result = pawn.Reserve((LocalTargetInfo)(Thing)bed, job, maxPawns, 0, errorOnFailed: errorOnFailed);
            return false;
        }
        if (pawn == null || !SqueezeUtil.IsSqueezePawn(pawn))
            return true;
        if (job.targetA.Cell.IsValid && !pawn.ageTracker.CurLifeStage.alwaysDowned && !job.forceSleep && !pawn.Reserve((LocalTargetInfo)job.targetA.Cell, job, errorOnFailed: errorOnFailed))
        {
            __result = false;
            return false;
        }
        __result = true;
        return false;
    }
}

// 260906修改，删除了Patch_MaxAssignedPawnsCount

//260906修改
[HarmonyPatch(typeof(PawnUIOverlay), "DrawPawnGUIOverlay")]
public static class Patch_SleepingNameInsideBed
{
    public static bool Prefix(PawnUIOverlay __instance)
    {
        Pawn pawn = Traverse.Create((object)__instance).Field("pawn").GetValue<Pawn>();
        if (pawn == null || !pawn.Spawned || pawn.Map == null || pawn.Map.fogGrid.IsFogged(pawn.Position) || !SqueezeUtil.IsSqueezePawn(pawn) || !pawn.GetPosture().InBed())
            return true;

        int? sleepingSlot;
        Building_Bed bed = pawn.CurrentBed(out sleepingSlot);
        if (bed == null || !sleepingSlot.HasValue || !SqueezeUtil.IsSqueezeBed(bed) || (pawn.IsMutant && pawn.mutant.Def.hideLabel))
            return true;

        Vector2 pos = GenMapUI.LabelDrawPosFor((Thing)pawn, -0.6f);

        // ---- 竖床床尾居中显示 ----
        bool isVertical = (bed.Rotation == Rot4.North || bed.Rotation == Rot4.South);
        if (isVertical)
        {
            int totalSlots = SqueezeUtil.LayoutSlots(bed);
            List<IntVec3> mousePositions = new List<IntVec3>();
            bool hasMouseAtFoot = false;

            for (int i = 0; i < totalSlots; i++)
            {
                Pawn occupant = bed.GetCurOccupant(i);
                if (occupant != null && SqueezeUtil.IsSqueezePawn(occupant) && occupant.Spawned && occupant.InBed() && occupant.CurrentBed() == bed)
                {
                    mousePositions.Add(occupant.Position);
                    // 获取当前槽位的床尾位置（无论单人床还是双人床）
                    IntVec3 footPos = bed.GetFootSlotPos(i);
                    if (occupant.Position == footPos)
                        hasMouseAtFoot = true;
                }
            }

            // 只有存在床尾鼠族时才应用居中
            if (mousePositions.Count > 0 && hasMouseAtFoot)
            {
                bool bedFacingSouth = bed.Rotation == Rot4.South;
                float footEndZ;
                if (bedFacingSouth)
                    footEndZ = mousePositions.Min(p => p.z);
                else
                    footEndZ = mousePositions.Max(p => p.z);

                if (Math.Abs(pawn.Position.z - footEndZ) < 0.01f)
                {
                    Vector3 worldCenter = pawn.Position.ToVector3() + new Vector3(0.5f, 0f, 0.5f);
                    Vector2 screenPos = Find.Camera.WorldToScreenPoint(worldCenter) / Prefs.UIScale;
                    screenPos.y = UI.screenHeight - screenPos.y;
                    pos = screenPos;
                }
            }
        }

        // ---- 边界裁剪 ----
        CellRect cellRect = SqueezeUtil.BedRect(bed);
        Vector2 uiPosition1 = new Vector3((float)cellRect.minX, 0.0f, (float)cellRect.minZ).MapToUIPosition();
        Vector2 uiPosition2 = new Vector3((float)(cellRect.maxX + 1), 0.0f, (float)cellRect.minZ).MapToUIPosition();
        Vector2 uiPosition3 = new Vector3((float)cellRect.minX, 0.0f, (float)(cellRect.maxZ + 1)).MapToUIPosition();
        Vector2 uiPosition4 = new Vector3((float)(cellRect.maxX + 1), 0.0f, (float)(cellRect.maxZ + 1)).MapToUIPosition();
        float num1 = Mathf.Min(Mathf.Min(uiPosition1.x, uiPosition2.x), Mathf.Min(uiPosition3.x, uiPosition4.x));
        float num2 = Mathf.Max(Mathf.Max(uiPosition1.x, uiPosition2.x), Mathf.Max(uiPosition3.x, uiPosition4.x));
        float num3 = Mathf.Min(Mathf.Min(uiPosition1.y, uiPosition2.y), Mathf.Min(uiPosition3.y, uiPosition4.y));
        float num4 = Mathf.Max(Mathf.Max(uiPosition1.y, uiPosition2.y), Mathf.Max(uiPosition3.y, uiPosition4.y));
        pos.x = Mathf.Clamp(pos.x, num1 + 10f, num2 - 10f);
        pos.y = Mathf.Clamp(pos.y, num3 + 8f, num4 - 8f);

        GenMapUI.DrawPawnLabel(pawn, pos);
        if (pawn.ShouldShowQuestionMark())
            pawn.Map.overlayDrawer.DrawOverlay((Thing)pawn, OverlayTypes.QuestionMark);
        Lord lord = pawn.GetLord();
        if (lord != null && lord.CurLordToil != null)
            lord.CurLordToil.DrawPawnGUIOverlay(pawn);

        return false;
    }
}

public class ThoughtWorker_AloneSleep : ThoughtWorker
{
    protected override ThoughtState CurrentStateInternal(Pawn p)
    {
        if (p == null || !SqueezeUtil.IsSqueezePawn(p) || !p.Spawned || p.CurJob == null || !p.GetPosture().InBed())
            return (ThoughtState)false;
        int? sleepingSlot;
        Building_Bed bed = p.CurrentBed(out sleepingSlot);
        return bed == null || !sleepingSlot.HasValue || !SqueezeUtil.IsSqueezeBed(bed) ? (ThoughtState)false : (ThoughtState)(SqueezeUtil.CountSqueezeSleepers(bed) == 1);
    }
}

public class ThoughtWorker_CrowdedSleep : ThoughtWorker
{
    protected override ThoughtState CurrentStateInternal(Pawn p)
    {
        if (p == null || !SqueezeUtil.IsSqueezePawn(p) || !p.Spawned || p.CurJob == null || !p.GetPosture().InBed())
            return (ThoughtState)false;
        int? sleepingSlot;
        Building_Bed bed = p.CurrentBed(out sleepingSlot);
        if (bed == null || !sleepingSlot.HasValue || !SqueezeUtil.IsSqueezeBed(bed))
            return (ThoughtState)false;
        int num = SqueezeUtil.CountSqueezeSleepers(bed);
        return SqueezeUtil.BaseSlots(bed) <= 1 ? (ThoughtState)(num >= 2) : (ThoughtState)(num > 2);
    }
}

//260906添加，（大概）修复在单人床上不能做爱的小bug
[HarmonyPatch(typeof(JobDriver_Lovin), "TryMakePreToilReservations")]
public static class Patch_LovinReserve
{
    public static bool Prefix(JobDriver_Lovin __instance, bool errorOnFailed, ref bool __result)
    {
        Pawn pawn = __instance.pawn;

        // 使用 Traverse 获取私有属性
        Building_Bed bed = Traverse.Create(__instance).Property("Bed").GetValue<Building_Bed>();
        Pawn partner = Traverse.Create(__instance).Property("Partner").GetValue<Pawn>();

        // 只有鼠族在挤压床上才走自定义逻辑
        if (bed == null || !SqueezeUtil.IsSqueezeBed(bed) || !SqueezeUtil.IsSqueezePawn(pawn) || !SqueezeUtil.IsSqueezePawn(partner))
            return true; // 非鼠族或非挤压床，走原版

        // 1. 预留伴侣
        if (!pawn.Reserve(partner, __instance.job, errorOnFailed: errorOnFailed))
        {
            __result = false;
            return false;
        }

        // 2. 预留床，使用 LayoutSlots（即 BaseSlots * 2）替代原版的 SleepingSlotsCount
        int maxPawns = SqueezeUtil.LayoutSlots(bed);
        if (!pawn.Reserve(bed, __instance.job, maxPawns, 0, errorOnFailed: errorOnFailed))
        {
            __result = false;
            return false;
        }

        __result = true;
        return false; // 完全接管，不执行原版方法
    }
}