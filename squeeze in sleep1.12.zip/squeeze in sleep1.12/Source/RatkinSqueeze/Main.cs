﻿using System.Collections.Generic;
using HarmonyLib;
using RimWorld;
using Verse;
using UnityEngine;
using System;
using System.Reflection;
using Verse.AI;
using Verse.AI.Group;
using System.Reflection.Emit;
using System.Linq;

#nullable disable
namespace RatkinSqueeze;

public class RatkinSqueezeMod : Mod
{
    public const string HarmonyId = "shuzu.ratkinsqueeze";

    public RatkinSqueezeMod(ModContentPack content)
      : base(content)
    {
        Harmony harmony = new Harmony("shuzu.ratkinsqueeze");
        harmony.PatchAll(Assembly.GetExecutingAssembly());
        Patch_CurrentBed.Apply(harmony);
        Log.Message("[挤一挤] 已加载：Harmony 补丁全部就绪（种族=Ratkin）。");
    }
}
public static class SqueezeUtil
{
    public const string RatkinRaceDefName = "Ratkin";

    public static bool IsSqueezePawn(Pawn pawn)
    {
        return pawn != null && pawn.def != null && pawn.RaceProps != null && pawn.RaceProps.Humanlike && pawn.def.defName == "Ratkin";
    }

    public static bool IsSqueezeBed(Building_Bed bed)
    {
        return bed != null && bed.def != null && bed.def.building != null && bed.def.building.bed_humanlike && !bed.Medical && !bed.ForHumanBabies && bed.def.size.x >= 1 && bed.def.size.z >= 2;
    }

    public static int BaseSlots(Building_Bed bed)
    {
        return bed == null || bed.def == null ? 1 : bed.def.size.x;
    }

    public static int EffSlotsFor(Pawn pawn, Building_Bed bed)
    {
        int num = SqueezeUtil.BaseSlots(bed);
        return SqueezeUtil.IsSqueezePawn(pawn) && SqueezeUtil.IsSqueezeBed(bed) ? num * 2 : num;
    }

    public static int LayoutSlots(Building_Bed bed)
    {
        int num = SqueezeUtil.BaseSlots(bed);
        return SqueezeUtil.IsSqueezeBed(bed) ? num * 2 : num;
    }

    public static int ReserveSlotsFor(Building_Bed bed)
    {
        return SqueezeUtil.IsSqueezeBed(bed) ? SqueezeUtil.BaseSlots(bed) * 2 : SqueezeUtil.BaseSlots(bed);
    }

    public static int CountSqueezeSleepers(Building_Bed bed)
    {
        if (bed == null || !bed.Spawned)
            return 0;
        int num1 = SqueezeUtil.LayoutSlots(bed);
        int num2 = 0;
        for (int slotIndex = 0; slotIndex < num1; ++slotIndex)
        {
            Pawn curOccupant = bed.GetCurOccupant(slotIndex);
            if (curOccupant != null && SqueezeUtil.IsSqueezePawn(curOccupant))
                ++num2;
        }
        return num2;
    }

    public static CellRect BedRect(Building_Bed bed) => bed.OccupiedRect();

    public static Vector3 BedRectCenterWorld(CellRect rect)
    {
        return new Vector3((float)((double)(rect.minX + rect.maxX) / 2.0 + 0.5), 0.0f, (float)((double)(rect.minZ + rect.maxZ) / 2.0 + 0.5));
    }

    public static bool HasOtherSharer(Pawn p, Building_Bed bed)
    {
        List<Pawn> ownersForReading = bed.OwnersForReading;
        if (ownersForReading != null)
        {
            for (int index = 0; index < ownersForReading.Count; ++index)
            {
                if (ownersForReading[index] != null && ownersForReading[index] != p)
                    return true;
            }
        }
        int num = SqueezeUtil.LayoutSlots(bed);
        for (int slotIndex = 0; slotIndex < num; ++slotIndex)
        {
            Pawn curOccupant = bed.GetCurOccupant(slotIndex);
            if (curOccupant != null && curOccupant != p)
                return true;
        }
        return false;
    }

    public static bool IdeoAllowsSharing(Pawn p, Building_Bed bed)
    {
        List<Pawn> ownersForReading = bed.OwnersForReading;
        if (ownersForReading != null)
        {
            for (int index = 0; index < ownersForReading.Count; ++index)
            {
                if (ownersForReading[index] != null && ownersForReading[index] != p && !BedUtility.WillingToShareBed(p, ownersForReading[index]))
                    return false;
            }
        }
        int num = SqueezeUtil.LayoutSlots(bed);
        for (int slotIndex = 0; slotIndex < num; ++slotIndex)
        {
            Pawn curOccupant = bed.GetCurOccupant(slotIndex);
            if (curOccupant != null && curOccupant != p && !BedUtility.WillingToShareBed(p, curOccupant))
                return false;
        }
        return true;
    }

    //260906新增
    public static float GetHeadDistance(Building_Bed bed, int slotIndex)
    {
        if (bed == null) return 999f;

        IntVec3 slotPos = bed.GetSleepingSlotPos(slotIndex);
        IntVec3 bedCenter = bed.Position;
        IntVec3 headDirection;

        switch (bed.Rotation.AsInt)
        {
            case 0: // North: 床头在 Z 负方向（Z 小）
                headDirection = new IntVec3(0, 0, -1);
                break;
            case 1: // East: 床头在 X 正方向（X 大）
                headDirection = new IntVec3(1, 0, 0);
                break;
            case 2: // South: 床头在 Z 正方向（Z 大）
                headDirection = new IntVec3(0, 0, 1);
                break;
            case 3: // West: 床头在 X 负方向（X 小）
                headDirection = new IntVec3(-1, 0, 0);
                break;
            default:
                return 999f;
        }

        // 计算槽位在床头方向上的投影值（越大越靠近床头）
        Vector3 dirVec = headDirection.ToVector3();
        Vector3 slotVec = slotPos.ToVector3() - bedCenter.ToVector3();
        return Vector3.Dot(slotVec, dirVec);
    }

    //260913修改
    public static int GetSlotColumn(Building_Bed bed, int slotIndex)
    {
        int baseSlots = BaseSlots(bed);
        if (baseSlots <= 1) return 0;
        return slotIndex % baseSlots;
    }

    public static bool HasOppositeRaceSleeper(Building_Bed bed, Pawn sleeper)
    {
        if (bed == null || sleeper == null) return false;

        // 只在单人床上生效（BaseSlots == 1）
        if (BaseSlots(bed) != 1) return false;

        bool sleeperIsRat = IsSqueezePawn(sleeper);

        int slots = LayoutSlots(bed);
        for (int i = 0; i < slots; i++)
        {
            Pawn occ = bed.GetCurOccupant(i);
            if (occ != null && occ != sleeper && IsSqueezePawn(occ) != sleeperIsRat)
                return true;
        }

        var owners = bed.OwnersForReading;
        if (owners != null)
        {
            for (int i = 0; i < owners.Count; i++)
            {
                Pawn o = owners[i];
                if (o != null && o != sleeper && IsSqueezePawn(o) != sleeperIsRat)
                    return true;
            }
        }
        return false;
    }
}

[HarmonyPatch(typeof(Building_Bed), "GetCurOccupantAt")]
public static class Patch_BedGetCurOccupantAt
{
    public static bool Prefix(Building_Bed __instance, IntVec3 pos, ref Pawn __result)
    {
        int num = SqueezeUtil.LayoutSlots(__instance);
        for (int index = 0; index < num; ++index)
        {
            if (__instance.GetSleepingSlotPos(index) == pos)
            {
                __result = __instance.GetCurOccupant(index);
                return false;
            }
        }
        __result = (Pawn)null;
        return false;
    }
}

[HarmonyPatch(typeof(Building_Bed), "GetCurOccupantSlotIndex")]
public static class Patch_BedGetCurOccupantSlotIndex
{
    public static bool Prefix(Building_Bed __instance, Pawn curOccupant, ref int __result)
    {
        int num = SqueezeUtil.EffSlotsFor(curOccupant, __instance);
        for (int slotIndex = 0; slotIndex < num; ++slotIndex)
        {
            if (__instance.GetCurOccupant(slotIndex) == curOccupant)
            {
                __result = slotIndex;
                return false;
            }
        }
        Log.Warning($"[挤一挤] 找不到 {(curOccupant != null ? curOccupant.ToString() : "null")} 所在的床位格。");
        __result = 0;
        return false;
    }
}

//260913修改
[HarmonyPatch(typeof(Building_Bed), "GetFootSlotPos")]
public static class Patch_BedGetFootSlotPos
{
    public static bool Prefix(Building_Bed __instance, int index, ref IntVec3 __result)
    {
        int baseSlots = SqueezeUtil.BaseSlots(__instance);
        if (index < 0 || index >= baseSlots * 2 || !SqueezeUtil.IsSqueezeBed(__instance))
            return true;

        int col = index % baseSlots;
        __result = BedUtility.GetFeetSlotPos(col, __instance.Position, __instance.Rotation, __instance.def.size);
        return false;
    }
}

[HarmonyPatch(typeof(Building_Bed), "GetSleepingSlotPos")]
public static class Patch_BedGetSleepingSlotPos
{
    public static bool Prefix(Building_Bed __instance, int index, ref IntVec3 __result)
    {
        int baseSlots = SqueezeUtil.BaseSlots(__instance);
        if (index < 0 || index >= baseSlots * 2 || !SqueezeUtil.IsSqueezeBed(__instance))
            return true;

        int col = index % baseSlots;
        bool isHead = index < baseSlots;

        if (isHead)
            __result = BedUtility.GetSleepingSlotPos(col, __instance.Position, __instance.Rotation, __instance.def.size);
        else
            __result = BedUtility.GetFeetSlotPos(col, __instance.Position, __instance.Rotation, __instance.def.size);

        return false;
    }
}

//260907修改
[HarmonyPatch(typeof(Building_Bed), "DrawGUIOverlay")]
public static class Patch_BedOwnerNamesLayout
{
    public static bool Prefix(Building_Bed __instance)
    {
        if (__instance.Medical || Find.CameraDriver.CurrentZoom != CameraZoomRange.Closest || !__instance.CompAssignableToPawn.PlayerCanSeeAssignments)
            return true;

        List<Pawn> ownersForReading = __instance.OwnersForReading;
        if (ownersForReading == null || ownersForReading.Count <= 1 || !SqueezeUtil.IsSqueezeBed(__instance))
            return true;

        int num1 = SqueezeUtil.BaseSlots(__instance);
        CellRect rect = SqueezeUtil.BedRect(__instance);
        IntVec3 sleepingSlotPos = __instance.GetSleepingSlotPos(0);
        IntVec3 footSlotPos = __instance.GetFootSlotPos(0);
        Vector3 vector3_1 = new Vector3((float)(sleepingSlotPos.x - footSlotPos.x), 0.0f, (float)(sleepingSlotPos.z - footSlotPos.z));
        float num2 = (float)Math.Sqrt((double)vector3_1.x * (double)vector3_1.x + (double)vector3_1.z * (double)vector3_1.z);
        if ((double)num2 < 0.0099999997764825821)
            return true;

        vector3_1.x /= num2;
        vector3_1.z /= num2;
        Vector3 vector3_2 = new Vector3(-vector3_1.z, 0.0f, vector3_1.x);
        float num3 = (double)Math.Abs(vector3_1.x) > 0.5 ? (float)(rect.maxX - rect.minX + 1) : (float)(rect.maxZ - rect.minZ + 1);
        Vector3 vector3_3 = SqueezeUtil.BedRectCenterWorld(rect);
        vector3_3.x -= vector3_1.x * (float)(((double)num3 - 1.0) / 2.0 * 0.5);
        vector3_3.z -= vector3_1.z * (float)(((double)num3 - 1.0) / 2.0 * 0.5);
        Color defaultThingLabelColor = GenMapUI.DefaultThingLabelColor;

        // 收集需要显示名称的 pawn
        List<Pawn> pawnList = new List<Pawn>();
        for (int index = 0; index < ownersForReading.Count; ++index)
        {
            Pawn pawn = ownersForReading[index];
            if (pawn != null && (!pawn.Spawned || !pawn.InBed() || pawn.CurrentBed() != __instance || !(pawn.Position == __instance.GetSleepingSlotPos(index))) && (!pawn.RaceProps.Animal || Prefs.AnimalNameMode.ShouldDisplayAnimalName(pawn)))
                pawnList.Add(pawn);
        }
        if (pawnList.Count == 0)
            return false;

        // 按列分组：左列（0,2）和右列（1,3），先绘制左列
        List<Pawn> leftColPawns = new List<Pawn>();
        List<Pawn> rightColPawns = new List<Pawn>();
        for (int i = 0; i < pawnList.Count; i++)
        {
            Pawn pawn = pawnList[i];
            int slotIndex = ownersForReading.IndexOf(pawn);
            int col = SqueezeUtil.GetSlotColumn(__instance, slotIndex);
            if (col == 0) leftColPawns.Add(pawn);
            else rightColPawns.Add(pawn);
        }

        List<Pawn> orderedPawns = new List<Pawn>();
        orderedPawns.AddRange(leftColPawns);
        orderedPawns.AddRange(rightColPawns);

        int colCount = num1;                 // 列数 = 床宽 = baseSlots

        Vector2 uiPosition1 = new Vector3((float)rect.minX, 0.0f, (float)rect.minZ).MapToUIPosition();
        Vector2 uiPosition2 = new Vector3((float)(rect.maxX + 1), 0.0f, (float)rect.minZ).MapToUIPosition();
        Vector2 uiPosition3 = new Vector3((float)rect.minX, 0.0f, (float)(rect.maxZ + 1)).MapToUIPosition();
        Vector2 uiPosition4 = new Vector3((float)(rect.maxX + 1), 0.0f, (float)(rect.maxZ + 1)).MapToUIPosition();

        float num6 = Mathf.Min(Mathf.Min(uiPosition1.x, uiPosition2.x), Mathf.Min(uiPosition3.x, uiPosition4.x));
        float num7 = Mathf.Max(Mathf.Max(uiPosition1.x, uiPosition2.x), Mathf.Max(uiPosition3.x, uiPosition4.x));
        float num8 = Mathf.Min(Mathf.Min(uiPosition1.y, uiPosition2.y), Mathf.Min(uiPosition3.y, uiPosition4.y));
        float num9 = Mathf.Max(Mathf.Max(uiPosition1.y, uiPosition2.y), Mathf.Max(uiPosition3.y, uiPosition4.y));

        for (int index = 0; index < orderedPawns.Count; ++index)
        {
            Pawn pawn = orderedPawns[index];
            int slotIndex = ownersForReading.IndexOf(pawn);

            int num10 = slotIndex % colCount;    // 列号
            float num12 = colCount > 1
                ? (num10 + 0.5f - colCount * 0.5f) * 0.84f
                : 0.0f;

            // 以床矩形中心为基准
            Vector3 v = vector3_3;
            // 横向偏移（宽度方向）
            v.x += vector3_2.x * num12;
            v.z += vector3_2.z * num12;

            // 纵向偏移：床头排（slotIndex 0、1）保持在中心，床尾排（slotIndex 2、3）向床尾方向移半格
            if (slotIndex >= SqueezeUtil.BaseSlots(__instance))
            {
                v.x -= vector3_1.x * 0.5f;
                v.z -= vector3_1.z * 0.5f;
            }

            Vector2 uiPosition5 = v.MapToUIPosition();
            uiPosition5.x = Mathf.Clamp(uiPosition5.x, num6 + 10f, num7 - 10f);
            uiPosition5.y = Mathf.Clamp(uiPosition5.y, num8 + 8f, num9 - 8f);

            GenMapUI.DrawThingLabel(uiPosition5, pawn.LabelShort, defaultThingLabelColor);
        }

        return false;
    }
}

[HarmonyPatch(typeof(RestUtility), "CanUseBedNow")]
public static class Patch_CanUseBedNow
{
    public static bool Prefix(
        Thing bedThing,
        Pawn sleeper,
        bool checkSocialProperness,
        bool allowMedBedEvenIfSetToNoCare,
        GuestStatus? guestStatusOverride,
        ref bool __result)
    {
        if (!(bedThing is Building_Bed bed)) return true;
        if (!SqueezeUtil.IsSqueezeBed(bed)) return true;

        // 双向、只在单人床生效
        if (SqueezeUtil.HasOppositeRaceSleeper(bed, sleeper))
        {
            __result = false;
            return false;
        }

        if (!SqueezeUtil.IsSqueezePawn(sleeper)) return true;

        // ================================================

        if (!bed.Spawned) { __result = false; return false; }
        if (bed.Map != sleeper.MapHeld) { __result = false; return false; }
        if (bed.IsBurning()) { __result = false; return false; }
        if (sleeper.HarmedByVacuum && bed.Position.GetVacuum(bed.Map) >= 0.5f) { __result = false; return false; }
        if (!RestUtility.CanUseBedEver(sleeper, bed.def)) { __result = false; return false; }
        if (bed.CompAssignableToPawn.IdeoligionForbids(sleeper)) { __result = false; return false; }

        int? assignedSleepingSlot;
        bool isOwner = bed.IsOwner(sleeper, out assignedSleepingSlot);
        int? sleepingSlot;
        bool isCurrentOccupant = sleeper.CurrentBed(out sleepingSlot) == bed;

        if (!isOwner && !isCurrentOccupant && !HasFreeWeightSlot(sleeper, bed))
        {
            __result = false;
            return false;
        }

        GuestStatus? gs = guestStatusOverride ?? sleeper.GuestStatus;
        bool isPrisoner = gs == GuestStatus.Prisoner;
        bool isSlave = gs == GuestStatus.Slave;

        if (checkSocialProperness && !bed.IsSociallyProper(sleeper, isPrisoner)) { __result = false; return false; }
        if (bed.ForPrisoners != isPrisoner) { __result = false; return false; }
        if (bed.ForSlaves != isSlave) { __result = false; return false; }
        if (bed.ForPrisoners && !bed.Position.IsInPrisonCell(bed.Map)) { __result = false; return false; }

        if (bed.Medical)
        {
            if (!allowMedBedEvenIfSetToNoCare && !HealthAIUtility.ShouldEverReceiveMedicalCareFromPlayer(sleeper)) { __result = false; return false; }
            if (!HealthAIUtility.ShouldSeekMedicalRest(sleeper)) { __result = false; return false; }
        }
        else
        {
            if (!isOwner && !BedOwnerWillShareForSqueeze(bed, sleeper, guestStatusOverride))
            {
                __result = false;
                return false;
            }
            if (isCurrentOccupant && sleepingSlot != assignedSleepingSlot) { __result = false; return false; }
        }

        if (sleeper.IsColonist && !isPrisoner)
        {
            Job curJob = sleeper.CurJob;
            if ((curJob == null || !curJob.ignoreForbidden) && !sleeper.Downed && bed.IsForbidden(sleeper))
            {
                __result = false;
                return false;
            }
        }

        __result = true;
        return false;
    }

    private static bool BedOwnerWillShareForSqueeze(Building_Bed bed, Pawn sleeper, GuestStatus? guestStatus)
    {
        if (bed.OwnersForReading == null || bed.OwnersForReading.Count == 0)
            return true;

        if (sleeper.IsPrisoner || guestStatus == GuestStatus.Prisoner
            || sleeper.IsSlave || guestStatus == GuestStatus.Slave)
        {
            return HasFreeWeightSlot(sleeper, bed);
        }

        if (!HasFreeWeightSlot(sleeper, bed)) return false;
        return IsAnyOwnerLovePartnerOf(bed, sleeper);
    }

    private static bool HasFreeWeightSlot(Pawn sleeper, Building_Bed bed)
    {
        int capacity = SqueezeUtil.BaseSlots(bed) * 2;
        int currentWeight = 0;
        var owners = bed.OwnersForReading;
        if (owners != null)
        {
            foreach (Pawn p in owners)
            {
                if (p == null) continue;
                currentWeight += SqueezeUtil.IsSqueezePawn(p) ? 1 : 2;
            }
        }
        int newWeight = SqueezeUtil.IsSqueezePawn(sleeper) ? 1 : 2;
        return (currentWeight + newWeight) <= capacity;
    }

    private static bool IsAnyOwnerLovePartnerOf(Building_Bed bed, Pawn sleeper)
    {
        var owners = bed.OwnersForReading;
        for (int i = 0; i < owners.Count; i++)
        {
            if (owners[i] != null && LovePartnerRelationUtility.LovePartnerRelationExists(sleeper, owners[i]))
                return true;
        }
        return false;
    }
}

// 260906修改（动态踢人：新来鼠族踢人类，新来人类踢鼠族）
[HarmonyPatch(typeof(Pawn_Ownership), "ClaimBedIfNonMedical")]
public static class Patch_ClaimBedIfNonMedical
{
    private static System.Reflection.MethodInfo ownedBedSetter;

    private static void SetOwnedBed(Pawn_Ownership ownership, Building_Bed bed)
    {
        if (ownedBedSetter == null)
            ownedBedSetter = AccessTools.PropertySetter(typeof(Pawn_Ownership), "OwnedBed");
        ownedBedSetter.Invoke(ownership, new object[] { bed });
    }

    public static bool Prefix(Pawn_Ownership __instance, Building_Bed newBed, ref bool __result)
    {
        Pawn pawn = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();

        if (pawn == null || newBed == null || newBed.Medical)
            return true;

        // ---- 死亡rest委托给原版 ----
        if (ModsConfig.BiotechActive && newBed.def == ThingDefOf.DeathrestCasket)
        {
            __result = __instance.ClaimDeathrestCasket(newBed);
            return false;
        }

        if (!SqueezeUtil.IsSqueezeBed(newBed))
            return true;

        if (newBed.IsOwner(pawn))
        {
            __result = false;
            return false;
        }

        if (SqueezeUtil.HasOtherSharer(pawn, newBed) && !SqueezeUtil.IdeoAllowsSharing(pawn, newBed))
        {
            __result = false;
            return false;
        }

        // ---- 计算权重 ----
        List<Pawn> owners = newBed.OwnersForReading;
        int capacity = SqueezeUtil.BaseSlots(newBed) * 2;
        int currentWeight = 0;
        if (owners != null)
        {
            foreach (Pawn p in owners)
            {
                if (p == null) continue;
                currentWeight += SqueezeUtil.IsSqueezePawn(p) ? 1 : 2;
            }
        }

        int newWeight = SqueezeUtil.IsSqueezePawn(pawn) ? 1 : 2;
        int totalWeight = currentWeight + newWeight;

        // ---- 空间足够 ----
        if (totalWeight <= capacity)
        {
            __instance.UnclaimBed();
            newBed.CompAssignableToPawn.ForceAddPawn(pawn);
            SetOwnedBed(__instance, newBed);
            __result = true;
            return false;
        }

        // ---- 需要踢人（动态优先级） ----
        int toKickWeight = totalWeight - capacity;
        List<Pawn> toKick = new List<Pawn>();
        int kickedWeight = 0;

        if (owners != null)
        {
            bool newIsRatkin = SqueezeUtil.IsSqueezePawn(pawn);

            if (newIsRatkin)
            {
                // 新来鼠族 → 优先踢非鼠族（权重2）
                for (int i = owners.Count - 1; i >= 0 && kickedWeight < toKickWeight; i--)
                {
                    Pawn p = owners[i];
                    if (p == null) continue;
                    if (!SqueezeUtil.IsSqueezePawn(p))
                    {
                        toKick.Add(p);
                        kickedWeight += 2;
                    }
                }
                // 还不够再踢鼠族
                for (int i = owners.Count - 1; i >= 0 && kickedWeight < toKickWeight; i--)
                {
                    Pawn p = owners[i];
                    if (p == null) continue;
                    if (SqueezeUtil.IsSqueezePawn(p))
                    {
                        toKick.Add(p);
                        kickedWeight += 1;
                    }
                }
            }
            else
            {
                // 新来非鼠族 → 优先踢鼠族（权重1）
                for (int i = owners.Count - 1; i >= 0 && kickedWeight < toKickWeight; i--)
                {
                    Pawn p = owners[i];
                    if (p == null) continue;
                    if (SqueezeUtil.IsSqueezePawn(p))
                    {
                        toKick.Add(p);
                        kickedWeight += 1;
                    }
                }
                // 还不够再踢非鼠族
                for (int i = owners.Count - 1; i >= 0 && kickedWeight < toKickWeight; i--)
                {
                    Pawn p = owners[i];
                    if (p == null) continue;
                    if (!SqueezeUtil.IsSqueezePawn(p))
                    {
                        toKick.Add(p);
                        kickedWeight += 2;
                    }
                }
            }
        }

        if (toKick.Count == 0)
        {
            __result = false;
            return false;
        }

        // ---- 执行踢人 ----
        CompAssignableToPawn comp = newBed.CompAssignableToPawn;
        foreach (Pawn p in toKick)
        {
            comp.ForceRemovePawn(p);
            p.ownership.UnclaimBed();

            if (p.Spawned && p.Map != null)
            {
                p.Map.reservationManager.ReleaseAllClaimedBy(p);
            }

            if (p.Spawned && p.InBed())
            {
                RestUtility.KickOutOfBed(p, newBed);
            }
        }

        // ---- 加入新指派者 ----
        __instance.UnclaimBed();
        newBed.CompAssignableToPawn.ForceAddPawn(pawn);
        SetOwnedBed(__instance, newBed);
        __result = true;
        return false;
    }
}

public static class Patch_CurrentBed
{
    public static void Apply(Harmony harmony)
    {
        MethodBase original = (MethodBase)AccessTools.Method(typeof(RestUtility), "CurrentBed", new System.Type[2]
        {
      typeof (Pawn),
      typeof (int?).MakeByRefType()
        });
        if (original != (MethodBase)null)
            harmony.Patch(original, new HarmonyMethod(typeof(Patch_CurrentBed), "Prefix"));
        else
            Log.Warning("[挤一挤] 未找到 RestUtility.CurrentBed(Pawn, out int?) 方法，相关补丁未生效。");
    }

    public static bool Prefix(Pawn p, out int? sleepingSlot, ref Building_Bed __result)
    {
        if (!SqueezeUtil.IsSqueezePawn(p))
        {
            sleepingSlot = new int?();
            return true;
        }
        sleepingSlot = new int?();
        if (p == null || !p.Spawned || p.CurJob == null || !p.GetPosture().InBed())
        {
            __result = (Building_Bed)null;
            return false;
        }

        // ---------- 修正开始 ----------
        Building_Bed bed = null;  // 明确声明类型
        List<Thing> thingList = p.Position.GetThingList(p.Map);
        for (int index = 0; index < thingList.Count; index++)
        {
            if (thingList[index] is Building_Bed foundBed)
            {
                bed = foundBed;
                break;
            }
        }
        // ---------- 修正结束 ----------

        if (bed == null)
        {
            __result = (Building_Bed)null;
            return false;
        }

        int num = SqueezeUtil.EffSlotsFor(p, bed);
        for (int slotIndex = 0; slotIndex < num; ++slotIndex)
        {
            if (bed.GetCurOccupant(slotIndex) == p)
            {
                sleepingSlot = new int?(slotIndex);
                __result = bed;
                return false;
            }
        }
        __result = (Building_Bed)null;
        return false;
    }
}

//260906修改
[HarmonyPatch(typeof(RestUtility), "GetBedSleepingSlotPosFor")]
public static class Patch_GetBedSleepingSlotPosFor
{
    public static bool Prefix(Pawn pawn, Building_Bed bed, ref IntVec3 __result)
    {
        if (!SqueezeUtil.IsSqueezePawn(pawn) || !SqueezeUtil.IsSqueezeBed(bed))
            return true;

        int? assignedSleepingSlot;
        if (bed.IsOwner(pawn, out assignedSleepingSlot))
        {
            __result = bed.GetSleepingSlotPos(assignedSleepingSlot.Value);
            return false;
        }

        int num = SqueezeUtil.EffSlotsFor(pawn, bed);
        List<Pawn> ownersForReading = bed.OwnersForReading;
        int count = ownersForReading == null ? 0 : ownersForReading.Count;

        // 按床头距离排序
        List<int> slotOrder = new List<int>();
        for (int i = 0; i < num; i++) slotOrder.Add(i);
        slotOrder.Sort((a, b) =>
            SqueezeUtil.GetHeadDistance(bed, b).CompareTo(SqueezeUtil.GetHeadDistance(bed, a))
        ); // 降序：离床头近的排前面

        foreach (int index in slotOrder)
        {
            Pawn curOccupant = bed.GetCurOccupant(index);
            if ((index >= count || ownersForReading[index] == null) && curOccupant == pawn)
            {
                __result = bed.GetSleepingSlotPos(index);
                return false;
            }
        }

        foreach (int index in slotOrder)
        {
            Pawn curOccupant = bed.GetCurOccupant(index);
            if ((index >= count || ownersForReading[index] == null) && curOccupant == null)
            {
                __result = bed.GetSleepingSlotPos(index);
                return false;
            }
        }

        Log.Error($"[挤一挤] 找不到适合 {(pawn != null ? pawn.ToString() : "null")} 的空床位格。");
        __result = bed.GetSleepingSlotPos(0);
        return false;
    }
}

//260914修改
[HarmonyPatch(typeof(PawnRenderer), "GetBodyPos")]
public static class Patch_GetBodyPosTail
{
    public static void Postfix(PawnRenderer __instance, ref Vector3 __result)
    {
        Pawn pawn = Traverse.Create(__instance).Field("pawn").GetValue<Pawn>();
        if (pawn == null || !pawn.Spawned) return;
        if (!SqueezeUtil.IsSqueezePawn(pawn)) return;
        if (!pawn.GetPosture().InBed()) return;

        int? sleepingSlot;
        Building_Bed bed = pawn.CurrentBed(out sleepingSlot);
        if (bed == null || !sleepingSlot.HasValue) return;
        if (!SqueezeUtil.IsSqueezeBed(bed)) return;

        int baseSlots = SqueezeUtil.BaseSlots(bed);
        bool showBody = bed.def.building.bed_showSleeperBody;

        // ---- 1. 床头 occupant ----
        Pawn[] headOccupant = new Pawn[baseSlots];
        for (int c = 0; c < baseSlots; c++)
            headOccupant[c] = bed.GetCurOccupant(c);

        // ---- 2. 每列是否含非鼠族 ----
        bool[] colHasNonRat = new bool[baseSlots];
        for (int s = 0; s < baseSlots * 2; s++)
        {
            Pawn occ = bed.GetCurOccupant(s);
            if (occ != null && !SqueezeUtil.IsSqueezePawn(occ))
                colHasNonRat[s % baseSlots] = true;
        }

        // ---- 3. 可用列建组 ----
        var group = new Dictionary<int, List<Pawn>>();
        for (int c = 0; c < baseSlots; c++)
        {
            if (colHasNonRat[c]) continue;
            group[c] = new List<Pawn>();
        }
        if (group.Count == 0) return;

        // ---- 4. 收集所有鼠族 occupant，按列是否禁用分类 ----
        var pendingAssign = new List<(Pawn p, int origCol)>();
        for (int s = 0; s < baseSlots * 2; s++)
        {
            Pawn occ = bed.GetCurOccupant(s);
            if (occ == null || !SqueezeUtil.IsSqueezePawn(occ)) continue;

            int col = s % baseSlots;
            bool isHead = s < baseSlots;

            if (colHasNonRat[col])
            {
                // 禁用列上的鼠族 → 待挤出
                pendingAssign.Add((occ, col));
            }
            else if (isHead)
            {
                // 可用列床头鼠族 → 归自己列
                group[col].Add(occ);
            }
            // 可用列床尾鼠族 → 第 5 步处理
        }

        // ---- 5. 可用列床尾鼠族分配到某组床头位 ----
        for (int s = baseSlots; s < baseSlots * 2; s++)
        {
            Pawn occ = bed.GetCurOccupant(s);
            if (occ == null || !SqueezeUtil.IsSqueezePawn(occ)) continue;
            int col = s % baseSlots;
            if (colHasNonRat[col]) continue;

            int targetCol = -1, bestTotal = int.MaxValue, bestDist = int.MaxValue;
            for (int c = 0; c < baseSlots; c++)
            {
                if (!group.ContainsKey(c)) continue;
                int total = group[c].Count;
                if (total >= 2) continue;
                int d = Math.Abs(c - col);
                if (total < bestTotal || (total == bestTotal && d < bestDist))
                {
                    bestTotal = total; bestDist = d; targetCol = c;
                }
            }
            if (targetCol < 0) continue;
            group[targetCol].Add(occ);
        }

        // ---- 6. 禁用列鼠族挤出到可用列（关键：统一在这里分配，所有 pawn 都能看到）----
        foreach (var (p, origCol) in pendingAssign)
        {
            int targetCol = -1, bestTotal = int.MaxValue, bestDist = int.MaxValue;
            for (int c = 0; c < baseSlots; c++)
            {
                if (!group.ContainsKey(c)) continue;
                int total = group[c].Count;
                if (total >= 2) continue;
                int d = Math.Abs(c - origCol);
                if (total < bestTotal || (total == bestTotal && d < bestDist))
                {
                    bestTotal = total; bestDist = d; targetCol = c;
                }
            }
            if (targetCol < 0) continue;
            group[targetCol].Add(p);
        }

        // ---- 7. 查自己在哪列 ----
        int myCol = -1, myIdx = -1;
        foreach (var kv in group)
        {
            int i = kv.Value.IndexOf(pawn);
            if (i >= 0) { myCol = kv.Key; myIdx = i; break; }
        }
        if (myCol < 0) return;

        List<Pawn> myGroup = group[myCol];
        int n = myGroup.Count;

        IntVec3 currentPos = pawn.Position;
        IntVec3 headPos = bed.GetSleepingSlotPos(myCol);
        Rot4 rot = bed.Rotation;

        if (showBody)
        {
            // ===== 无被子 =====
            if (n >= 2)
            {
                // 同列多个鼠族 → 按组内 idx 分别渲染到床头/床尾
                IntVec3 targetSlot = (myIdx == 0)
                    ? bed.GetSleepingSlotPos(myCol)
                    : bed.GetFootSlotPos(myCol);
                __result.x += (targetSlot.x + 0.5f) - (currentPos.x + 0.5f);
                __result.z += (targetSlot.z + 0.5f) - (currentPos.z + 0.5f);
            }
            else
            {
                bool moveToHead = (myIdx == 0) && (headOccupant[myCol] == null);
                if (moveToHead)
                {
                    __result.x += (headPos.x + 0.5f) - (currentPos.x + 0.5f);
                    __result.z += (headPos.z + 0.5f) - (currentPos.z + 0.5f);
                }
                else
                {
                    if (rot == Rot4.North || rot == Rot4.South)
                        __result.x += (headPos.x + 0.5f) - (currentPos.x + 0.5f);
                    else
                        __result.z += (headPos.z + 0.5f) - (currentPos.z + 0.5f);
                }
            }
        }
        else
        {
            // ===== 有被子：整组渲染在床头格，n==2 时左右各偏 0.3 =====
            const float kHalfSpread = 0.3f;
            float offset = (n == 2) ? (myIdx == 0 ? -kHalfSpread : kHalfSpread) : 0f;

            Vector3 lateralDir;
            if (rot == Rot4.North || rot == Rot4.South)
                lateralDir = new Vector3(1f, 0f, 0f);
            else
                lateralDir = new Vector3(0f, 0f, 1f);

            float dx = (headPos.x + 0.5f) - (currentPos.x + 0.5f) + lateralDir.x * offset;
            float dz = (headPos.z + 0.5f) - (currentPos.z + 0.5f) + lateralDir.z * offset;

            __result.x += dx;
            __result.z += dz;
        }
    }
}

[HarmonyPatch(typeof(RestUtility), "IsValidBedFor")]
public static class Patch_IsValidBedFor
{
    public static bool Prefix(
      Thing bedThing,
      Pawn sleeper,
      Pawn traveler,
      bool checkSocialProperness,
      bool allowMedBedEvenIfSetToNoCare,
      bool ignoreOtherReservations,
      GuestStatus? guestStatus,
      ref bool __result)
    {
        if (!(bedThing is Building_Bed buildingBed) || !SqueezeUtil.IsSqueezeBed(buildingBed))
            return true;
        bool flag1 = false;
        if (!RestUtility.CanUseBedNow(bedThing, sleeper, checkSocialProperness, allowMedBedEvenIfSetToNoCare, guestStatus))
            flag1 = true;
        if (!flag1 && !traveler.CanReach((LocalTargetInfo)(Thing)buildingBed, PathEndMode.OnCell, Danger.Some))
            flag1 = true;
        int maxPawns = SqueezeUtil.ReserveSlotsFor(buildingBed);
        if (!flag1 && !sleeper.HasReserved((LocalTargetInfo)(Thing)buildingBed) && !traveler.CanReserve((LocalTargetInfo)(Thing)buildingBed, maxPawns, 0, ignoreOtherReservations: ignoreOtherReservations))
            flag1 = true;
        if (!flag1 && traveler.HasReserved<JobDriver_TakeToBed>((LocalTargetInfo)(Thing)buildingBed, new LocalTargetInfo?((LocalTargetInfo)(Thing)sleeper)))
            flag1 = true;
        if (!flag1 && buildingBed.IsForbidden(traveler))
            flag1 = true;
        GuestStatus? nullable1 = guestStatus;
        bool flag2 = nullable1.GetValueOrDefault() == GuestStatus.Prisoner && nullable1.HasValue;
        GuestStatus? nullable2 = guestStatus;
        bool flag3 = nullable2.GetValueOrDefault() == GuestStatus.Slave && nullable2.HasValue;
        if (!flag1 && !flag2 && !flag3 && buildingBed.Faction != traveler.Faction && (traveler.HostFaction == null || buildingBed.Faction != traveler.HostFaction))
            flag1 = true;
        if (!flag1 && ModsConfig.AnomalyActive && sleeper.IsMutant && sleeper.needs.rest == null && sleeper.mutant.Def.entitledToMedicalCare && !buildingBed.Medical)
            flag1 = true;
        __result = !flag1;
        return false;
    }
}

[HarmonyPatch(typeof(JobDriver_LayDown), "TryMakePreToilReservations")]
public static class Patch_LayDownReserve
{
    public static bool Prefix(JobDriver_LayDown __instance, bool errorOnFailed, ref bool __result)
    {
        Pawn pawn = __instance.pawn;
        Building_Bed bed = __instance.Bed;
        Verse.AI.Job job = __instance.job;
        if (bed != null)
        {
            if (!SqueezeUtil.IsSqueezeBed(bed))
                return true;
            // 去掉种族判断
            int maxPawns = SqueezeUtil.ReserveSlotsFor(bed);
            __result = pawn.Reserve((LocalTargetInfo)(Thing)bed, job, maxPawns, 0, errorOnFailed: errorOnFailed);
            return false;
        }
        if (pawn == null || !SqueezeUtil.IsSqueezePawn(pawn))
            return true;
        if (job.targetA.Cell.IsValid && !pawn.ageTracker.CurLifeStage.alwaysDowned && !job.forceSleep
            && !pawn.Reserve((LocalTargetInfo)job.targetA.Cell, job, errorOnFailed: errorOnFailed))
        {
            __result = false;
            return false;
        }
        __result = true;
        return false;
    }
}

// 260906修改，删除了Patch_MaxAssignedPawnsCount

//260906修改
[HarmonyPatch(typeof(PawnUIOverlay), "DrawPawnGUIOverlay")]
public static class Patch_SleepingNameInsideBed
{
    public static bool Prefix(PawnUIOverlay __instance)
    {
        Pawn pawn = Traverse.Create((object)__instance).Field("pawn").GetValue<Pawn>();
        if (pawn == null || !pawn.Spawned || pawn.Map == null || pawn.Map.fogGrid.IsFogged(pawn.Position) || !SqueezeUtil.IsSqueezePawn(pawn) || !pawn.GetPosture().InBed())
            return true;

        int? sleepingSlot;
        Building_Bed bed = pawn.CurrentBed(out sleepingSlot);
        if (bed == null || !sleepingSlot.HasValue || !SqueezeUtil.IsSqueezeBed(bed) || (pawn.IsMutant && pawn.mutant.Def.hideLabel))
            return true;

        Vector2 pos = GenMapUI.LabelDrawPosFor((Thing)pawn, -0.6f);

        // ---- 竖床床尾居中显示 ----
        bool isVertical = (bed.Rotation == Rot4.North || bed.Rotation == Rot4.South);
        if (isVertical)
        {
            int totalSlots = SqueezeUtil.LayoutSlots(bed);
            List<IntVec3> mousePositions = new List<IntVec3>();
            bool hasMouseAtFoot = false;

            for (int i = 0; i < totalSlots; i++)
            {
                Pawn occupant = bed.GetCurOccupant(i);
                if (occupant != null && SqueezeUtil.IsSqueezePawn(occupant) && occupant.Spawned && occupant.InBed() && occupant.CurrentBed() == bed)
                {
                    mousePositions.Add(occupant.Position);
                    // 获取当前槽位的床尾位置（无论单人床还是双人床）
                    IntVec3 footPos = bed.GetFootSlotPos(i);
                    if (occupant.Position == footPos)
                        hasMouseAtFoot = true;
                }
            }

            // 只有存在床尾鼠族时才应用居中
            if (mousePositions.Count > 0 && hasMouseAtFoot)
            {
                bool bedFacingSouth = bed.Rotation == Rot4.South;
                float footEndZ;
                if (bedFacingSouth)
                    footEndZ = mousePositions.Min(p => p.z);
                else
                    footEndZ = mousePositions.Max(p => p.z);

                if (Math.Abs(pawn.Position.z - footEndZ) < 0.01f)
                {
                    Vector3 worldCenter = pawn.Position.ToVector3() + new Vector3(0.5f, 0f, 0.5f);
                    Vector2 screenPos = Find.Camera.WorldToScreenPoint(worldCenter) / Prefs.UIScale;
                    screenPos.y = UI.screenHeight - screenPos.y;
                    pos = screenPos;
                }
            }
        }

        // ---- 边界裁剪 ----
        CellRect cellRect = SqueezeUtil.BedRect(bed);
        Vector2 uiPosition1 = new Vector3((float)cellRect.minX, 0.0f, (float)cellRect.minZ).MapToUIPosition();
        Vector2 uiPosition2 = new Vector3((float)(cellRect.maxX + 1), 0.0f, (float)cellRect.minZ).MapToUIPosition();
        Vector2 uiPosition3 = new Vector3((float)cellRect.minX, 0.0f, (float)(cellRect.maxZ + 1)).MapToUIPosition();
        Vector2 uiPosition4 = new Vector3((float)(cellRect.maxX + 1), 0.0f, (float)(cellRect.maxZ + 1)).MapToUIPosition();
        float num1 = Mathf.Min(Mathf.Min(uiPosition1.x, uiPosition2.x), Mathf.Min(uiPosition3.x, uiPosition4.x));
        float num2 = Mathf.Max(Mathf.Max(uiPosition1.x, uiPosition2.x), Mathf.Max(uiPosition3.x, uiPosition4.x));
        float num3 = Mathf.Min(Mathf.Min(uiPosition1.y, uiPosition2.y), Mathf.Min(uiPosition3.y, uiPosition4.y));
        float num4 = Mathf.Max(Mathf.Max(uiPosition1.y, uiPosition2.y), Mathf.Max(uiPosition3.y, uiPosition4.y));
        pos.x = Mathf.Clamp(pos.x, num1 + 10f, num2 - 10f);
        pos.y = Mathf.Clamp(pos.y, num3 + 8f, num4 - 8f);

        GenMapUI.DrawPawnLabel(pawn, pos);
        if (pawn.ShouldShowQuestionMark())
            pawn.Map.overlayDrawer.DrawOverlay((Thing)pawn, OverlayTypes.QuestionMark);
        Lord lord = pawn.GetLord();
        if (lord != null && lord.CurLordToil != null)
            lord.CurLordToil.DrawPawnGUIOverlay(pawn);

        return false;
    }
}

public class ThoughtWorker_AloneSleep : ThoughtWorker
{
    protected override ThoughtState CurrentStateInternal(Pawn p)
    {
        if (p == null || !SqueezeUtil.IsSqueezePawn(p) || !p.Spawned || p.CurJob == null || !p.GetPosture().InBed())
            return (ThoughtState)false;
        int? sleepingSlot;
        Building_Bed bed = p.CurrentBed(out sleepingSlot);
        return bed == null || !sleepingSlot.HasValue || !SqueezeUtil.IsSqueezeBed(bed) ? (ThoughtState)false : (ThoughtState)(SqueezeUtil.CountSqueezeSleepers(bed) == 1);
    }
}

public class ThoughtWorker_CrowdedSleep : ThoughtWorker
{
    protected override ThoughtState CurrentStateInternal(Pawn p)
    {
        if (p == null || !SqueezeUtil.IsSqueezePawn(p) || !p.Spawned || p.CurJob == null || !p.GetPosture().InBed())
            return (ThoughtState)false;
        int? sleepingSlot;
        Building_Bed bed = p.CurrentBed(out sleepingSlot);
        if (bed == null || !sleepingSlot.HasValue || !SqueezeUtil.IsSqueezeBed(bed))
            return (ThoughtState)false;
        int num = SqueezeUtil.CountSqueezeSleepers(bed);
        return SqueezeUtil.BaseSlots(bed) <= 1 ? (ThoughtState)(num >= 2) : (ThoughtState)(num > 2);
    }
}

//260913修改
[HarmonyPatch(typeof(JobDriver_Lovin), "TryMakePreToilReservations")]
public static class Patch_LovinReserve
{
    public static bool Prefix(JobDriver_Lovin __instance, bool errorOnFailed, ref bool __result)
    {
        Pawn pawn = __instance.pawn;
        Building_Bed bed = Traverse.Create(__instance).Property("Bed").GetValue<Building_Bed>();
        Pawn partner = Traverse.Create(__instance).Property("Partner").GetValue<Pawn>();

        if (bed == null || !SqueezeUtil.IsSqueezeBed(bed))
            return true;

        if (!pawn.Reserve(partner, __instance.job, errorOnFailed: errorOnFailed))
        {
            __result = false;
            return false;
        }

        int maxPawns = SqueezeUtil.ReserveSlotsFor(bed);
        if (!pawn.Reserve(bed, __instance.job, maxPawns, 0, errorOnFailed: errorOnFailed))
        {
            __result = false;
            return false;
        }

        __result = true;
        return false;
    }
}